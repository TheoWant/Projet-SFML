#include <SFML/Graphics.hpp>
#include <iostream>
#include <map>
#include "Tilemap.h"
#include "enemy.h"
#include "player.h"

using namespace std;
using namespace sf;
typedef Vector2f vec2;
typedef Vector2i vec2i;



int main()
{
    RenderWindow window(sf::VideoMode(550, 380), "SFML works!");
    Tilemap T;
    Texture playerTexture, maptexture, enemyTexture, textureTest;

    Enemy ghost;
    Player player;

    playerTexture.loadFromFile("ghostSprite.png", IntRect(0, 0, 15, 15));

    maptexture.loadFromFile("foresttiles2-t.png");

    textureTest.loadFromFile("ghost.png");
    
    Sprite test;
    Sprite player;

    test.setTexture(enemyTexture);

    T.loadLevel(maptexture);

    ghost.loadEnemy(enemyTexture);
    player.loadPlayerTexture(playerTexture);
    

    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
        {
            test.move(-0.2f, 0);
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
        {
            test.move(0.2f, 0);
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
        {
            test.move(0, -0.2f);
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
        {
            test.move(0, 0.2f);
        }

        window.clear();

        T.draw(window);
        window.draw(test);
        window.display();
        
    }

    return 0;
}