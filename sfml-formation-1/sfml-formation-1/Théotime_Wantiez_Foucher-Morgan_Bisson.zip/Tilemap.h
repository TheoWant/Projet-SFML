#pragma once
#include <vector>
using namespace std;

class Tilemap
{
public:
    void loadLevel(sf::Texture& t);
    void draw(sf::RenderWindow& window);
protected:
    std::vector<sf::Sprite> Tiles, TilesBack;
};